package com.netguard.app

import android.app.Activity
import android.net.TrafficStats
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputType
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 13, 25)
    private val panel = Color.rgb(17, 27, 46)
    private val cyan = Color.rgb(0, 220, 255)
    private val white = Color.WHITE
    private val handler = Handler(Looper.getMainLooper())
    private var lastRx = TrafficStats.getTotalRxBytes()
    private var lastTx = TrafficStats.getTotalTxBytes()
    private var remainingMb = 0.0
    private lateinit var speed: TextView
    private lateinit var upload: TextView
    private lateinit var consumed: TextView
    private lateinit var remaining: TextView
    private lateinit var cardInput: EditText
    private lateinit var usedInput: EditText

    private val ticker = object : Runnable {
        override fun run() {
            val rx = TrafficStats.getTotalRxBytes()
            val tx = TrafficStats.getTotalTxBytes()
            if (rx >= 0 && tx >= 0 && lastRx >= 0 && lastTx >= 0) {
                val down = ((rx - lastRx).coerceAtLeast(0)) / 1024.0
                val up = ((tx - lastTx).coerceAtLeast(0)) / 1024.0
                speed.text = String.format(Locale.US, "%.1f KB/s", down)
                upload.text = String.format(Locale.US, "%.1f KB/s", up)
            } else {
                speed.text = "غير متاح على هذا الجهاز"
            }
            lastRx = rx
            lastTx = tx
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        handler.post(ticker)
    }

    private fun label(text: String, size: Float, color: Int = white): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(22, 18, 22, 18)
        setBackgroundColor(panel)
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(0, 10, 0, 10) }
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 24)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(page)
        page.addView(label("NET GUARD", 28f, cyan).apply { setTypeface(null, Typeface.BOLD) })
        page.addView(label("مراقبة الإنترنت واستهلاك البيانات", 14f, Color.LTGRAY))

        val live = card()
        live.addView(label("سرعة التنزيل الحالية", 16f, Color.LTGRAY))
        speed = label("0.0 KB/s", 34f, cyan).apply { setTypeface(null, Typeface.BOLD) }
        live.addView(speed)
        live.addView(label("سرعة الرفع", 14f, Color.LTGRAY))
        upload = label("0.0 KB/s", 22f)
        live.addView(upload)
        page.addView(live)

        val tracker = card()
        tracker.addView(label("حساب كرت الإنترنت", 20f, cyan))
        cardInput = EditText(this).apply {
            hint = "حجم الكرت بالميجابايت"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine()
            setTextColor(white); setHintTextColor(Color.GRAY)
        }
        usedInput = EditText(this).apply {
            hint = "البيانات المستهلكة بالميجابايت"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine()
            setTextColor(white); setHintTextColor(Color.GRAY)
        }
        tracker.addView(cardInput)
        tracker.addView(usedInput)
        val calc = Button(this).apply {
            text = "احسب المتبقي"
            setOnClickListener { calculateCard() }
        }
        tracker.addView(calc)
        consumed = label("المستهلك: —", 16f)
        remaining = label("المتبقي: —", 20f, cyan)
        tracker.addView(consumed)
        tracker.addView(remaining)
        page.addView(tracker)

        val info = card()
        info.addView(label("معلومات مهمة", 18f, cyan))
        info.addView(label("السرعة تُقاس من حركة بيانات الهاتف والشبكة على مستوى الجهاز.", 14f))
        info.addView(label("حساب المتبقي من الكرت يدوي: أدخل حجم الكرت والمستهلك الفعلي من مزود الخدمة.", 14f))
        info.addView(label("تفاصيل استهلاك كل تطبيق تحتاج منح صلاحية الوصول إلى إحصائيات الاستخدام، وستُضاف في إصدار لاحق.", 14f))
        page.addView(info)

        setContentView(scroll)
    }

    private fun calculateCard() {
        val total = cardInput.text.toString().toDoubleOrNull()
        val used = usedInput.text.toString().toDoubleOrNull()
        if (total == null || used == null || total <= 0 || used < 0) {
            Toast.makeText(this, "أدخل حجم الكرت والاستهلاك بشكل صحيح", Toast.LENGTH_LONG).show()
            return
        }
        val left = (total - used).coerceAtLeast(0.0)
        consumed.text = String.format(Locale.US, "المستهلك: %.2f MB", used)
        remaining.text = String.format(Locale.US, "المتبقي: %.2f MB (%.1f%%)", left, (left / total * 100).coerceIn(0.0, 100.0))
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }
}
